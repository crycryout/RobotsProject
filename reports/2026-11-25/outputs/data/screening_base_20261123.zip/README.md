# Base-policy screening, 2026-11-23

Cosmos3-Edge-Policy-DROID **base policy** (no adapter) on the 26 single-object pick-and-place candidates of the train split (`train_v1.md` §3).

**Settings:**
- 12 environments per task, one batch each, run under the frozen base checkpoint;
- `default` prompt, official horizon;
- RoboLab initial-pose randomization `--init-pose-noise 0.1` (±10 cm, yaw ±60°).

**Seeds and pairing.** Each task's batch seed is in `summary_default.csv` (`seed`), computed as `stable_seed(20261123, "track", task, "default")`. With 12 environments and one run, a given seed reproduces the same 12 layouts and the same policy-noise seeds. So any later checkpoint run with these seeds pairs episode by episode with this base, on (task, env).

**Origin.** Copied from `training/runs/v1_T_01/` (`counters/episodes_screen_*.parquet`, `counters/episodes_round0.parquet`, `selection.json`, `state.json`). The originals stay there, because `check.sh` and `training/v1_eval.py --pair-screening` read them from that path. The raw rollouts (logs, frames, latents) were on scratch and were deleted after round 0.

| File | Content |
| --- | --- |
| `summary_default.csv` | One row per task: successes / held out of 12, mean final progress P, median steps, wrong-grab events, selection group, v1 selection, seed, batch time |
| `episodes_default.parquet` / `.csv` | All 312 episodes: task, env, seed, success, steps, final_p, ever_held, time_to_first_hold, grasps, drops, wrong-grab events, return at chunk 0 |
| `per_task/episodes_screen_<Task>.parquet` | The same rows, one file per task (the original layout) |
| `episodes_specific_round0.parquet` / `.csv` | Base policy at the `specific` prompt for the 6 v1-selected tasks (72 episodes, v1 round 0). These seeds differ from the seeds v2 used at `specific`, so this table is not paired with them. |
| `selection.json` | v1 selection rule and per-task table (train / retention / dead, success contrast) |

**Groups (v1 rule):**
- retention: ≥ 10/12 successes;
- train: ≥ 3/12 held and ≤ 9/12 successes;
- dead: < 3/12 held.

The v2 runs select per (task, level) pair instead; see `train_v2.md` §2.
